<?php
include_once '../dashboard/connect.php';

//Session
session_start();
if(!ISSET($_SESSION['username']))
{
    header("location:../login/login.php");
}

$result = mysqli_query($conn,"SELECT * FROM posts");
?>

<html>
    <head>
        <title> Technical Support Community Forum Discussions</title>
    </head>
    <body>
        <div>
        <a href="myposts.php"><button>My Posts</button></a>
        <a href="createpost.php"><button>Create Posts</button></a>

        </div>
        <?php
        if (mysqli_num_rows($result) > 0) {
        ?>
        <table>
        
        <tr>
            <td>Post ID</td>
            <td>Username</td>
            <td>Post Title</td>
            <td>Post Content</td>
            <td>Action</td>
        </tr>
        <?php
        $i=0;
        while($row = mysqli_fetch_array($result)) {
        ?>
        <tr>
            <td><?php echo $row["post_id"]; ?></td>
            <td><?php echo $row["username"]; ?></td>
            <td><?php echo $row["post_title"]; ?></td>
            <td><?php echo $row["post_text"]; ?></td>
            <td>
            <?php echo "<a href='view.php?post_id=". $row['post_id'] ."' title='View Record'><img src='view.png'></a>"; ?>
            <?php echo "<a href='reply.php?post_id=". $row['post_id'] ."' title='View Record'><img src='reply.png'></a>"; ?>

            </td>
        </tr>
        <?php
        $i++;
        }
        ?>
        </table>
        <?php
        }
        else{
            echo "No result found";
        }
        ?>
    </body>
</html>