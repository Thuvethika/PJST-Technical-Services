<?php
//Session
session_start();
if(!ISSET($_SESSION['username']))
{
    header("location:../login/login.php");
}
?>
<html>

</html>