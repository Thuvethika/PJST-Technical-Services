<?php
//include config file
include_once '../dashboard/connect.php';

//Session
session_start();
if(!ISSET($_SESSION['username']))
{
    header("location:../login/login.php");
}


// Check existence of id parameter before processing further
if(isset($_GET["post_id"]) ){  
    
    // Prepare a select statement
    $sql = "SELECT * FROM reply WHERE post_id = ?";
    
    if($stmt = mysqli_prepare($conn, $sql)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, "i", $param_id);
        
        // Set parameters
        $param_id = trim($_GET["post_id"]);
        
        // Attempt to execute the prepared statement
        if(mysqli_stmt_execute($stmt)){
            $result = mysqli_stmt_get_result($stmt);    
        } else{
            echo "Oops! Something went wrong. Please try again later.";
        }
    }
     
    // Close statement
    mysqli_stmt_close($stmt);
    
    // Close connection
    mysqli_close($conn);

    
}
?>

<html>
    <head>
        <title>Replies</title>
    </head>
    <body>
        <?php
        if (mysqli_num_rows($result) > 0) {
        ?>
        <table>
        
        <tr>
            <td>Reply ID</td>
            <td>Username</td>
            <td>Reply Content</td>
            <td>Time</td>
            <td>Post Id</td>
            <td>Action</td>
        </tr>
        <?php
        $i=0;
        while($row = mysqli_fetch_array($result)) {
        ?>
        <tr>
            <td><?php echo $row["reply_id"]; ?></td>
            <td><?php echo $row["reply_owner"]; ?></td>
            <td><?php echo $row["reply_text"]; ?></td>
            <td><?php echo $row["reply_create_time"]; ?></td>
            <td><?php echo $row["post_id"]; ?></td>

            <td>
            <?php echo "<a href='viewreply.php?reply_id=". $row['reply_id'] ."' title='View Record'><img src='view.png'></a>"; ?>

            </td>
        </tr>
        <?php
        $i++;
        }
        ?>
        </table>
        <?php
        }
        else{
            echo "No replies available";
        }
        ?>
    </body>
</html>