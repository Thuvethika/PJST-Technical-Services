<?php
//include config file
include_once '../dashboard/connect.php';
//Session
session_start();
if(!ISSET($_SESSION['username']))
{
    header("location:../login/login.php");
}

// Check existence of id parameter before processing further
if(isset($_GET["post_id"]) ){  
    
    // Prepare a select statement
    $sql = "SELECT * FROM posts WHERE post_id = ?";
    
    if($stmt = mysqli_prepare($conn, $sql)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, "i", $param_id);
        
        // Set parameters
        $param_id = trim($_GET["post_id"]);
        
        // Attempt to execute the prepared statement
        if(mysqli_stmt_execute($stmt)){
            $result = mysqli_stmt_get_result($stmt);
    
            if(mysqli_num_rows($result) == 1){
                /* Fetch result row as an associative array. Since the result set contains only one row, we don't need to use while loop */
                $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                
               
            } else{
                // URL doesn't contain valid id parameter. Redirect to error page
                header("location: error.php");
                exit();
            }
            
        } else{
            echo "Oops! Something went wrong. Please try again later.";
        }
    }
     
    // Close statement
    mysqli_stmt_close($stmt);
    
    // Close connection
    mysqli_close($conn);

    
}
?>

<html>
    <head>
        <title>Post ID <?php echo $row['post_id']?></title>
    </head>
    <body>
        <div class="">
            <h1><?php echo $row['post_title']?></h1>
            <p>Created by: <?php echo $row['username']?> on <?php echo $row['post_create_time'] ?></p>
            <p><?php echo $row['post_text']?></p>
            <?php echo "<a href='replies.php?post_id=". $row['post_id'] ."' title='View Record'><button type='button'>See Replies</button></a>"; ?>
            

        </div>
    </body>
</html>