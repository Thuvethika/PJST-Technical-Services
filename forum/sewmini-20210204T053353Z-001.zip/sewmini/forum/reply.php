<?php
//include config file
include_once '../dashboard/connect.php';

//Session
session_start();
if(!ISSET($_SESSION['username']))
{
    header("location:../login/login.php");
}

// Check existence of id parameter before processing further
if(isset($_GET["post_id"]) ){  
    
    // Prepare a select statement
    $sql = "SELECT * FROM posts WHERE post_id = ?";
    
    if($stmt = mysqli_prepare($conn, $sql)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, "i", $param_id);
        
        // Set parameters
        $param_id = trim($_GET["post_id"]);
        
        // Attempt to execute the prepared statement
        if(mysqli_stmt_execute($stmt)){
            $result = mysqli_stmt_get_result($stmt);
    
            if(mysqli_num_rows($result) == 1){
                /* Fetch result row as an associative array. Since the result set contains only one row, we don't need to use while loop */
                $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                
               
            } else{
                // URL doesn't contain valid id parameter. Redirect to error page
                header("location: error.php");
                exit();
            }
            
        } else{
            echo "Oops! Something went wrong. Please try again later.";
        }
    }
     
    // Close statement
    mysqli_stmt_close($stmt);
    
    // Close connection
    mysqli_close($conn);

    
}

if(isset($_POST['submit']))
{	 
	 $reply_owner = $_POST['reply_owner'];
     $reply_text = $_POST['reply_text'];
     $post_id = $_POST['post_id'];
	 
	 $sql = "INSERT INTO reply (reply_owner,reply_text,post_id)
	 VALUES ('$reply_owner','$reply_text','$post_id')";
	 if (mysqli_query($conn, $sql)) {

        header("location: discussion.php");
        
	 } else {
		echo "Error: " . $sql . "
" . mysqli_error($conn);
	 }
	 mysqli_close($conn);
}
?>

<html>
    <head>
        <title>Reply to Post ID <?php echo $row['post_id']?></title>
    </head>
    <body>
        <div class="">
            <h1><?php echo $row['post_title']?></h1>
            <p><?php echo $row['post_text']?></p>
        </div>
        <div class="">
            <form action="reply.php" method="POST">
                    <label for="reply_owner"><b>Username</b></label>
                    <input text="username" name="reply_owner" id="reply_owner" placeholder="Enter your username" required><br >
                
                    <label for="reply_text"><b>Post content</b></label><br >
                    <textarea  rows="10" cols="60" name="reply_text" id="reply_text"  placeholder="Write Your reply here" required></textarea><br >

                    <input type="hidden" name="post_id" id="post_id" value="<?php echo $row['post_id']?>">
                    <button type="submit" name="submit">Submit</button>
            </form>
        </div>
       
    </body>
</html>